// const User = require('../models/user');
// const createUser = async(userData)=>{
//        const user = new User(userData);
//        return user.save();
// };
// const findByEnrollmentNumber = async(enrollmentNumber)=>{
//     return User.findOne({enrollmentNumber});
// };
// const findAdmin = async()=>{
//     return User.findOne({role: 'admin'});
// };
// module.exports = {
//     createUser,
//     findByEnrollmentNumber,findAdmin
// };