
// const Records = require('../models/record');
// const findByEnrollmentAndYear = async(enrollmentNumber,yearOfPassout)=>{
//     return Records.findOne({enrollmentNumber,yearOfPassout});
// };
// module.exports = {
//     findByEnrollmentAndYear
// };